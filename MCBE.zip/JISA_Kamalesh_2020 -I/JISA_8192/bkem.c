 
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gmp.h>
#include "bkem.h"
#include <time.h>
//clock_t t,t1,t0,t2,t4;

int num_recip=2048;

void setup_global_system(bkem_global_params_t *gps, const char *pstr, int N) {
    
    bkem_global_params_t params;
    params = pbc_malloc(sizeof(struct bkem_global_params_s));

    params->N = N;
    
    pairing_init_set_str(params->pairing, pstr);

    *gps = params;
}


void setup(bkem_system_t *sys, bkem_global_params_t gps) 
{
    	//t0 = clock(); 
   	bkem_system_t gbs;
    	bkem_secret_key_t sk;
    	gbs = pbc_malloc(sizeof(struct bkem_system_s));
    	gbs->PK = pbc_malloc(sizeof(struct pubkey_s));
// ---------------------------------Choose random generator g1 --------------------------------------------
    	element_init_G1(gbs->PK->g, gps->pairing);
    	element_random(gbs->PK->g);
// ---------------------------------random alpha in Zn ---------------------------------------------------
    	element_t alpha;
    	element_init_Zr(alpha, gps->pairing);
    	element_random(alpha);
// ---------------------------------random gamma in Zn-----------------------------------------------------
    	element_t gamma;
    	element_init_Zr(gamma, gps->pairing);
    	element_random(gamma);
    	
// ===================================Compute the component of MPK===========================================
  	
  	element_init_G1(gbs->PK->v, gps->pairing);
  	element_pow_zn(gbs->PK->v,gbs->PK->g,gamma);
   	//element_printf("The value of v=g_1^(gamma) is %B\n\n",v);
   	
//---------------------------------store alpha^i ------------------------------------------------------------
	element_init_Zr(gbs->alpha[0], gps->pairing);
    	element_set1(gbs->alpha[0]);
    	//element_printf("The value of alpha^(0) is %B\n\n",gbs->alpha[0]);
  	for (int j = 1; j <= 2*MAX_N; ++j)  
  	{
  		element_init_Zr(gbs->alpha[j], gps->pairing);
    		element_mul(gbs->alpha[j],gbs->alpha[j-1],alpha);
    		//element_printf("The value of alpha^(%d) is %B\n\n",j,gbs->alpha[j]);
  	}	
//--------------------------------compute (g_1)^(alpha^i)-----------------------------------------------------
  
  	for (int j = 0; j <= 2*MAX_N; ++j)  
  	{
  		element_init_G1(gbs->X[j], gps->pairing);
    		element_pow_zn(gbs->X[j],gbs->PK->g,gbs->alpha[j]);
    		//element_printf("The value of g^alpha^(%d) is %B\n\n",j,gbs->X[j]);
  	}
//---------------------------------Secret key SK_i------------------------------------------------------------
   	element_t sum_alpha,r1,r2,r3,r4;

   	for (int j = 1; j <= MAX_m; ++j) 
   	{	
   		element_init_Zr(gbs->channel_sum[j], gps->pairing);
   		element_set0(gbs->channel_sum[j]);
        	for (int i = 0; i < MAX_n; ++i)
         	{
            		element_add(gbs->channel_sum[j], gbs->channel_sum[j], gbs->alpha[i+(j-1)*MAX_n]); 
            		//printf("---------%d---------%d-------%d\n",j,i,i+(j-1)*MAX_n);
            	}
        
        //element_printf("The value of channel_sum[%d] of alphas is %B\n\n",j, gbs->channel_sum[j]);    	
    	}
    	
    	for (int j = 1; j <= MAX_m; ++j) 
    	{
        	for (int i = 0; i < MAX_n; ++i)
         	{
			element_init_G1(gbs->d[j][i][0], gps->pairing);
            		element_pow_zn(gbs->d[j][i][0],gbs->X[i+j], gamma);
            		//element_printf("Secret Key [%d][%d][0] = %B\n\n", j,i, gbs->d[j][i][0]);
            		element_init_G1(gbs->d[j][i][1], gps->pairing);
            		element_init_Zr(r1, gps->pairing);
            		element_sub(r1, gbs->channel_sum[j], gbs->alpha[i+j]);
            		element_init_Zr(r2, gps->pairing);
            		element_mul(r2,r1,gamma);
            		element_pow_zn(gbs->d[j][i][1],gbs->PK->g, r2);
            		//element_printf("Secret Key [%d][%d][1] = %B\n\n", j,i, gbs->d[j][i][1]); 
            	}
        }      
	*sys = gbs; 
 }
//----------------------------Key Gen is done -----------------------------------------------------------------


//===================================== Encryption =====================================================

void get_enc_key(header_t hdr,  bkem_system_t gbs, bkem_global_params_t gps) 
{	
        
        element_t s,t11,t12,t13,t14,t15,t16,t17,t18,t19,r1,ct_1,ct_2;
        int z1,z2,z3;
	element_init_Zr(s, gps->pairing);
	element_random(s);
//-------------------------------------1st ciphertext component (ct_1) --------------------------------
  	element_init_G1(t11, gps->pairing);
  	element_set(t11,gbs->X[MAX_N+1]);
 	for(int j=0;j<num_recip;++j)
 	{
 		element_mul(t11,t11,gbs->X[MAX_N+1-j]);
 		
 	}
        element_init_G1(t12, gps->pairing);
        element_mul(t12,t11,gbs->PK->v);
        element_init_G1(gbs->ct_1, gps->pairing);
        element_pow_zn(gbs->ct_1,t12,s);
        //element_printf("The 1st ciphertext component %B\n",gbs->ct_1); 
        
//-------------------------------------2nd ciphertext component (ct_2) --------------------------------
        element_init_G1(gbs->ct_2, gps->pairing);
        element_pow_zn(gbs->ct_2,gbs->PK->g,s);
        //element_printf("The 2nd ciphertext component %B\n",gbs->ct_2); 	
        
//-------------------------------------compute group key for each channel ---------------------------------------------
	
	for (int j = 0; j < 4; ++j) 
	 {	
	 	element_init_Zr(t13, gps->pairing);
		element_set0(t13);
	    	for(int i=0; i<MAX_n;++i)
	    	{
	    		element_add(t13,t13,gbs->alpha[i+j*MAX_n]);	
	    	}
	    	
	    	element_init_G1(t14, gps->pairing);
	    	element_pow_zn(t14,gbs->PK->g,t13);
	    	element_init_G1(t15, gps->pairing);
	    	element_pow_zn(t15,gbs->PK->v,s);
	    	element_init_GT(t16, gps->pairing);
	    	pairing_apply(t16, t14, t15, gps->pairing);
	    	//--------------------------------------------------------
	    	element_init_Zr(t17, gps->pairing);
	    	element_mul(t17,gbs->alpha[1],s);
	    	element_init_G1(t18, gps->pairing);
	    	element_mul(t18,gbs->PK->g,t17);
	    	element_init_GT(t19, gps->pairing);
	    	pairing_apply(t19, gbs->X[MAX_N], t18, gps->pairing);
	    	element_init_GT(gbs->Gkey[j], gps->pairing);
	    	element_mul(gbs->Gkey[j],t19,t16);
	    	//element_printf("The group key for $%d$-th channel %B\n",j,gbs->Gkey[j]);
		    	  					
    	}
	
}

//========================================= Decryption ==============================================

void get_decryption_key(bkem_global_params_t gps, bkem_system_t gbs, pubkey_t PK)
 {
 	int j=1;// 0th channel
 	int i=5;// 5th user of 0th channel
 		
 //--------------------------------------------------------------------------------------------------
   	int ii=i*MAX_n+j;
   	element_t t21,t22,t23,t24,t25,t26,t27,t28,t29;
 	element_init_GT(t21, gps->pairing);
 	pairing_apply(t21, gbs->X[i+MAX_n*j],gbs->ct_1, gps->pairing);
 	for (int jj = 0; jj < num_recip; ++jj) 
	 {	
	 	element_init_G1(t22, gps->pairing);
	 	element_set1(t22);
	    	element_mul(t22,t22,gbs->X[MAX_N+1+ii-jj]);	
	 }
 	
 	//element_printf("The product is %B\n\n",t22);
 	element_init_G1(t23, gps->pairing);
 	element_div(t23,t22, gbs->X[ii]);
 	element_init_G1(t24, gps->pairing);
 	element_mul(t24,t23, gbs->d[j][i][0]);
 	element_init_GT(t25, gps->pairing);
 	pairing_apply(t25, t24, gbs->ct_2, gps->pairing);
 	element_init_GT(t26, gps->pairing);
 	element_div(t26, t21, t25);
 	element_init_G1(t27, gps->pairing);
 	element_mul(t27, gbs->d[j][i][0], gbs->d[j][i][1]);
 	element_init_GT(t28, gps->pairing);
 	pairing_apply(t28, t27, gbs->ct_2, gps->pairing);
 	element_init_GT(t29, gps->pairing);
 	element_mul(t29, t28, t26);
 	//element_printf("The recovered group key %B\n\n", t29);
 	
}


void free_global_params(bkem_global_params_t gbs) {
    if (!gbs)
        return;

    pairing_clear(gbs->pairing);
    free(gbs);
}

void free_pubkey(pubkey_t pk, bkem_global_params_t gbs) {
    if (!pk)
        return;

    element_clear(pk->g);

    int i;
    for (i = 0; i <= gbs->N; ++i) {
        element_clear(pk->g_i[i]);
    }

    //for (i = 0; i < gbs->A; ++i) {
       // element_clear(pk->v_i[0]);
    //}

}

void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs) {
    if (!sys)
        return;

    free_pubkey(sys->PK, gbs);

    int i;
    /*for (i = 0; i < gbs->N; ++i) {
        element_clear(sys->d_i[i]);
    }*/
}
