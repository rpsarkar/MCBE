 
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gmp.h>
#include "bkem.h"
#include <time.h>

void setup_global_system(bkem_global_params_t *gps, const char *pstr, int N) {
    
    bkem_global_params_t params;
    params = pbc_malloc(sizeof(struct bkem_global_params_s));

    params->N = N;
    
    pairing_init_set_str(params->pairing, pstr);

    *gps = params;
}

void setup(bkem_system_t *sys, bkem_global_params_t gps) 
{
    
    // 
    bkem_system_t gbs;
    bkem_secret_key_t sk;
    gbs = pbc_malloc(sizeof(struct bkem_system_s));
    gbs->PK = pbc_malloc(sizeof(struct pubkey_s));

    //--------------------------------------Choose random generator g -------------------------------------
    element_init_G1(gbs->PK->g, gps->pairing);
    element_random(gbs->PK->g);
    
    //--------------------------------------Choose random generator gg -------------------------------------
    element_init_G1(gbs->PK->gg, gps->pairing);
    element_random(gbs->PK->gg);

    //-------------------------------------- random alpha Zn ----------------------------------------------
    //element_t alpha;
    element_init_Zr(gbs->PK->alpha, gps->pairing);
    element_random(gbs->PK->alpha);
    
    //-------------------------------------- random beta Zn ----------------------------------------------
    element_t beta;
    element_init_Zr(beta, gps->pairing);
    element_random(beta);
    
    //-------------------------------------- random gamma Zn ----------------------------------------------
    element_t gamma;
    element_init_Zr(gamma, gps->pairing);
    element_random(gamma);
    
    //--------------------------------------store x[j] in Zn -----------------------------------------------
    
    for (int j=1;j<=MAX_m;++j)
    {
    	element_init_Zr(gbs->PK->x[j], gps->pairing);
    	element_random(gbs->PK->x[j]);
    	//element_printf(" The value of x[%d] is %B\n\n",j,gbs->PK->x[j]);
    }
   
    //---------------------------------------compute (g_1)^(alpha^i)----------------------------------------
    
   element_t t11;
   element_init_Zr(t11, gps->pairing);
   element_set1(t11);   
   for(int j=0;j<=MAX_N;++j)
   {
   	element_init_G1(gbs->PK->g_i[j], gps->pairing);
   	element_pow_zn(gbs->PK->g_i[j],gbs->PK->g,t11);
   	//element_printf("(g_1)^(alpha^{%d}) = %B\n\n",j, gbs->PK->g_i[j]);
   	element_mul(t11,t11,gbs->PK->alpha);
   }
   //---------------------------------------compute (ghat_1)^(alpha^i)----------------------------------------
   for(int i = 0; i <=MAX_N; i++) 
   {
        element_init_G1(gbs->PK->gh_i[i], gps->pairing);
        element_pow_zn(gbs->PK->gh_i[i], gbs->PK->g_i[i], beta);
        //element_printf("(ghat_1)^(alpha^{%d}) = %B\n",i, gbs->PK->gh_i[i]);
   
  }
  //---------------------------------------compute (ghat_2)^(alpha^k) for k in [0,N-2]--------------------------
 
   element_init_G1(gbs->PK->gg_i[0], gps->pairing);
   element_pow_zn(gbs->PK->gg_i[0],gbs->PK->gg, beta);
   //element_printf("(ghat_2)^(alpha^{0}) = %B\n", gbs->PK->gg_i[0]);
   for(int i = 1; i <= MAX_N-2; i++)
    {
    
        element_init_G1(gbs->PK->gg_i[i], gps->pairing);
        element_pow_zn(gbs->PK->gg_i[i], gbs->PK->gg_i[i-1], gbs->PK->alpha);
        //element_printf("(ghat_2)^(alpha^{%d}) = %B\n",i, gbs->PK->gg_i[i]);
    }
    
    //---------------------------------------compute (g_1)^(gamma.x[j]) for j in [1,m]--------------------------
   
    for (int j=1;j<=MAX_m;++j)
    {
    	element_t temp;
    	element_init_Zr(temp, gps->pairing);
    	element_mul(temp, gbs->PK->x[j],gamma);
    	element_init_G1(gbs->PK->X[j], gps->pairing);
    	element_pow_zn(gbs->PK->X[j],gbs->PK->g,temp);
    	//element_printf(" The value of X[%d]=(g_1)^(gamma.x[%d]) is %B\n\n",j,j,gbs->PK->X[j]);
    }
    
    //---------------------------------------compute (g_1)^(gamma),  (g_1)^(alpha.gamma)---------------------------
       
     element_init_G1(gbs->PK->v_i[0], gps->pairing);
     element_pow_zn(gbs->PK->v_i[0], gbs->PK->g, gamma);
     //element_printf(" The value of (g_1)^(gamma) is %B\n\n",gbs->PK->v_i[0]);
     element_init_G1(gbs->PK->v_i[1], gps->pairing);
     element_pow_zn(gbs->PK->v_i[1], gbs->PK->v_i[0], gbs->PK->alpha);
     //element_printf(" The value of (g_1)^(gamma.alpha) is %B\n\n",gbs->PK->v_i[1]);
     
//-------------------------------------------Compute private keys--------------------------------------------------
     element_t d, d1;
     int j,jj,ii;
     for (int i = 0; i < MAX_N; i++)
     {
     	j=i/MAX_n+1;
     	ii=i%MAX_n;
     	//printf("The user index  and channel index corresponding to %d is.............. %d and %d \n\n",i,ii,j);
     	//printf("the channel index corresponding to %d is %d\n\n",i,j);
     	element_init_Zr(d, gps->pairing);
    	element_init_Zr(d1, gps->pairing);
  	element_set_si(d,i);
        //element_printf("d = %B\n", d);
        element_add(d,gbs->PK->alpha,d);
      	//element_printf("d = %B\n", d);
        element_div(d1,gamma, d);
        //element_printf("d1 = %B\n", d1);
        element_init_G1(gbs->d[j][ii][0], gps->pairing);
        element_pow_zn(gbs->d[j][ii][0], gbs->PK->gg, d1);
    	//element_printf("The first component of secret key d[%d][%d][0]= %B\n", j,ii, gbs->d[j][ii][0]);
    	element_init_Zr(gbs->d[j][ii][1], gps->pairing);
     	element_set(gbs->d[j][ii][1],gbs->PK->x[j]);
     	//element_printf("The second component of secret key d[%d][%d][1]= %B\n",j,ii, gbs->d[j][ii][1]);	
      }
	
 *sys = gbs;
   
 }
 
//=======================================================================================================================
 
element_t* multpoly1(element_t *p1,int d1,element_t *p2,int d2, bkem_global_params_t gps)
{ 
        int i,j;
        element_t *p; 
        element_t h; 
        element_init_Zr(h, gps->pairing);
        p=(element_t *)malloc((1+d1+d2)*sizeof(element_t)); //creating the new polynomial of degree d1+d2+1
        for(i=0;i<=d1+d2;i++)
        {
        	element_init_Zr(p[i], gps->pairing);
	        element_set_si(p[i],0);
	}
        for(i=0;i<=d1;i++)
        { 
               for(j=0;j<=d2;j++)
               {
               	element_mul(h,p1[i], p2[j]);
                       element_add(p[i+j],p[i+j], h);
               } //assigning coefficients to the various indices of the final polynomial
        }
        return(p); 
}



//----------------------------------------Encryption ---------------------------------------------------------

void get_enc_key(header_t hdr,  bkem_system_t gbs, bkem_global_params_t gps) 
{	
        int num_recip= 8192;
        element_t s,t3,t5,t6,t7,r1;
        element_t t11,t12,t13,t14,t15,t16,t17,t18,t19;
	element_init_Zr(s, gps->pairing);
	element_random(s);
	//printf("The no of the subscriber set %d\n",num_recip);
	
/*	element_t *q0,*q1,*q3;
	element_t *q[MAX_N+1];
	q1=(element_t *)malloc((MAX_N+3)*sizeof(element_t));
	q0=(element_t *)malloc((MAX_N+1)*sizeof(element_t));
	q3=(element_t *)malloc((MAX_N+1)*sizeof(element_t));
	
	
	for(int i=0;i<=MAX_N;i++)
    	{ 
    		q[i]=(element_t *)malloc((MAX_N+2)*sizeof(element_t));
        	for(int j=0;j<=1;j++)
       	 {
        		if (j==0 && i< num_recip)
        		{	
        			element_init_Zr(q[i][j],gps->pairing);
                       	element_set_si(q[i][j],i+1);
                       	
                	}
         		if (j==0 && i>= num_recip && i< MAX_N) 
         		{
         			element_init_Zr(q[i][j],gps->pairing); 
                       	element_set_si(q[i][j],i+1-MAX_N);
                	}
           		if (j==0 && i== MAX_N) 
           		{
           			element_init_Zr(q[i][j],gps->pairing);
                       	element_set_si(q[i][j],MAX_N);
                       	element_neg(q[i][j],q[i][j]);
               	}                       
         		if (j==1)
         		{ 
         			element_init_Zr(q[i][j],gps->pairing);
                       	element_set_si(q[i][j],1);
               	}
               	//element_printf(".......q[i=%d][j=%d] is %B\n\n",i,j,q[i][j]);
         	}
     	}
	
	for(int i=0;i<num_recip;i++)
     	{
      		q0=multpoly1(q0,i,q[i],1, gps);printf("DONE\n\n");
     	}
        for(int i=256;i<gps->N;i++)
     	{
      		q3=multpoly1(q3,i-num_recip,q[i],1, gps);
     	}

	
	q1=multpoly1(q0,num_recip,q3,gps->N-num_recip, gps);
*/	

	for (int i = 0; i < num_recip; ++i) 
	 {
	 	//-------------------------------------1st ciphertext component (C_1) --------------------------------
	    	
	    	element_init_Zr(t11,gps->pairing);
	    	element_init_Zr(t12,gps->pairing);
	    	element_set1(t12);
	    	element_set_si(t11,i);
    	
	    	element_init_Zr(t13,gps->pairing);
	    	element_add(t13,gbs->PK->alpha,t11);
	    	element_mul(t12,t12,t13);
    	 }
   	//element_printf("The value Product  of all (alpha+i) is %B \n\n",t12);

	for (int i = num_recip; i <= MAX_N; ++i) 
	 {
	 	//-------------------------------------1st ciphertext component (C_1) --------------------------------
	    	element_init_Zr(t11,gps->pairing);
	    	element_init_Zr(t16,gps->pairing);
	    	element_init_Zr(t14,gps->pairing);
	    	element_set1(t14);
	    	element_set_si(t11,i);
	    	element_set1(t16);
	    	element_set_si(t16,MAX_N);
	    	element_init_Zr(t15,gps->pairing);
	    	element_add(t15,gbs->PK->alpha,t11);
	    	element_sub(t15,t15,t16);
	    	element_mul(t14,t14,t15);	
	    	
   	 }
   	//element_printf("The value Product  of all (alpha+i-N) is %B \n\n",t14);
   	element_init_Zr(t17,gps->pairing);  
   	element_mul(t17,t12,t14); //compute P(alpha)
   	element_init_Zr(gbs->P_a,gps->pairing);
   	element_set(gbs->P_a,t17);
   	element_mul(t17,t17,s);
   	element_init_G1(gbs->C_1,gps->pairing); 
   	element_pow_zn(gbs->C_1,gbs->PK->gh_i[0],t17);	
	//element_printf("The 1st component C_1 is %B \n\n",gbs->C_1);
	element_init_G1(gbs->C_2,gps->pairing); 
   	element_pow_zn(gbs->C_2,gbs->PK->v_i[0],s);	
	//element_printf("The 2nd component C_2 is %B \n\n",gbs->C_2);
	
//------------------------------------Session Key K-----------------------------------------------------
	element_init_GT(gbs->K, gps->pairing);
    	pairing_apply(gbs->K, gbs->PK->v_i[1],gbs->PK->gg_i[MAX_N-2], gps->pairing);	
    	element_pow_zn(gbs->K,gbs->K,s);
    	//element_printf("The Session key for all group is %B\n\n", gbs->K);
//------------------------------------Group Key K_j ----------------------------------------------------
	for( int j=1;j<=MAX_m;++j)
	{
		element_init_GT(gbs->K_j[j], gps->pairing);
		element_init_G1(t19, gps->pairing);
    		element_pow_zn(t19,gbs->PK->X[j],s);
    		//element_mul(gbs->K_j[j],t19,gbs->K);
    		//element_printf("The Session key for the group %d is %B\n\n",j, t19);
	}
	
	
       element_clear(s);
         	
}


void get_decryption_key(bkem_global_params_t gps, bkem_system_t gbs, pubkey_t PK)
 {
 	int i=25;
 	int j=i/MAX_n+1;
     	int ii=i%MAX_n;
  	element_t t1,t11,t2,t3,t4,t5,t6,t7,t8,t9,Guess_M_x;
 	element_init_Zr(t11, gps->pairing);
 	element_set_si(t11,MAX_N-1);
 	element_init_Zr(t1, gps->pairing);
 	element_set_si(t1,i);
 	element_init_Zr(t2, gps->pairing);
 	element_add(t2,gbs->PK->alpha,t1);
 	element_init_Zr(t3, gps->pairing);
 	element_div(t3,gbs->P_a,t2);
 	element_init_Zr(t4, gps->pairing);
 	element_pow_zn(t4,gbs->PK->alpha,t11);
 	element_sub(t4,t4,t3);//compute P_i(alpha)
 	element_init_G1(t5, gps->pairing);
 	element_pow_zn(t5,gbs->PK->gg_i[0],t4);
 	element_init_GT(t6, gps->pairing);
 	pairing_apply(t6, gbs->C_1, gbs->d[j][ii][0], gps->pairing);
 	element_init_GT(t7, gps->pairing);
 	pairing_apply(t7, gbs->C_2, t5, gps->pairing);
 	element_mul(t7,t6, t7);
 	//element_printf("The recovered session key is %B\n\n",t7);
 	element_init_G1(t8, gps->pairing);
 	element_pow_zn(t8,gbs->C_2, gbs->d[j][ii][1]);
 	//element_printf("The recovered group key for the channel %d is %B\n\n",j,t8);
 
 
 	
}


void free_global_params(bkem_global_params_t gbs) {
    if (!gbs)
        return;

    pairing_clear(gbs->pairing);
    free(gbs);
}

void free_pubkey(pubkey_t pk, bkem_global_params_t gbs) {
    if (!pk)
        return;

    element_clear(pk->g);

    int i;
    for (i = 0; i <= gbs->N; ++i) {
        element_clear(pk->g_i[i]);
    }

    //for (i = 0; i < gbs->A; ++i) {
       // element_clear(pk->v_i[0]);
    //}

}

void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs) {
    if (!sys)
        return;

    free_pubkey(sys->PK, gbs);

    int i;
    /*for (i = 0; i < gbs->N; ++i) {
        element_clear(sys->d_i[i]);
    }*/
}
