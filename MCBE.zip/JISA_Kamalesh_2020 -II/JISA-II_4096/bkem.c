#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gmp.h>
#include "bkem.h"
#include <time.h>
//clock_t t,t1,t0,t2,t4;
int num_recip=1024;
void setup_global_system(bkem_global_params_t *gps, const char *pstr, int N) {
    
    bkem_global_params_t params;
    params = pbc_malloc(sizeof(struct bkem_global_params_s));

    params->N = N;
    
    pairing_init_set_str(params->pairing, pstr);

    *gps = params;
}

int sizeOf(ID ij)
{
    return (int)(2*sizeof(int));
}

void hashID(element_t hash, ID IDij, bkem_global_params_t gps)
{	
    element_init_Zr(hash, gps->pairing);
    element_from_hash(hash, &IDij, sizeOf(IDij));
}


void setup(bkem_system_t *sys, bkem_global_params_t gps) 
{
    	//t0 = clock(); 
   	bkem_system_t gbs;
    	bkem_secret_key_t sk;
    	gbs = pbc_malloc(sizeof(struct bkem_system_s));
    	gbs->PK = pbc_malloc(sizeof(struct pubkey_s));
// ---------------------------------Choose random generator g1 --------------------------------------------
    	element_init_G1(gbs->PK->g, gps->pairing);
    	element_random(gbs->PK->g);
// ---------------------------------random alpha in Zn ---------------------------------------------------
    	element_t alpha;
    	element_init_Zr(alpha, gps->pairing);
    	element_random(alpha);
// ---------------------------------random gamma in Zn-----------------------------------------------------
    	element_t gamma;
    	element_init_Zr(gamma, gps->pairing);
    	element_random(gamma);
    	
// ===================================Compute the component of MPK===========================================
  	
  	element_init_G1(gbs->PK->v, gps->pairing);
  	element_pow_zn(gbs->PK->v,gbs->PK->g,gamma);
   	//element_printf("The value of v=g_1^(gamma) is %B\n\n",v);
   	
//---------------------------------store pi_0=g^(alpha.(alpha^N-1)/(alpha-1)) ------------------------------------------------------------
	element_t t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23,t24,t25,t26;
	element_init_Zr(t11, gps->pairing);
	element_set1(t11);
	for(int j=0;j<MAX_N;++j)
	{
		element_mul(t11,t11,alpha);
	}
	//element_printf("g^N= %B\n",t11);
	element_init_Zr(t12, gps->pairing);
	element_init_Zr(t13, gps->pairing);
	element_init_Zr(t14, gps->pairing);
	element_init_Zr(t15, gps->pairing);
	element_init_Zr(t16, gps->pairing);
	element_set1(t12);
	element_sub(t13,t11,t12);
	element_sub(t14,alpha,t12);
	element_mul(t15,t13,alpha);
	element_div(t16,t15,t14);
	element_init_G1(gbs->PK->pi_0, gps->pairing);
	element_mul(gbs->PK->pi_0,gbs->PK->g,t16);
	//--------------------------------store beta_[u]------------------------------------------------------
	for(int j=0;j<MAX_m;++j)
	{
		element_init_Zr(gbs->PK->beta[j], gps->pairing);
		element_random(gbs->PK->beta[j]);
		//element_printf("the value of beta[%d] is %B\n\n",j,gbs->PK->beta[j]);	
	}
	element_init_G1(gbs->PK->g_i[0], gps->pairing);
    	element_set(gbs->PK->g_i[0],gbs->PK->g);
    	//element_printf("g_i[0] = %B\n", gbs->PK->g_i[0]);
    	element_init_G1(gbs->PK->g_ii[0], gps->pairing);
    	element_pow_zn(gbs->PK->g_ii[0],gbs->PK->g,alpha);
    	//element_printf("g_ii[0] = %B\n", gbs->PK->g_ii[0]);
    	element_init_Zr(t17, gps->pairing);
    	element_set1(t17);
    	element_init_Zr(t18, gps->pairing);
    	element_set_si(t18,MAX_N);
    	element_init_Zr(t19, gps->pairing);
    	element_add(t19,t18,t17);
    	element_init_G1(gbs->PK->g_iii[0], gps->pairing);
    	element_pow_zn(gbs->PK->g_iii[0],gbs->PK->g,t19);
    	//element_printf("g_iii[1025] = %B\n", gbs->PK->g_iii[0]);
    	element_init_G1(gbs->PK->g_iiii[0], gps->pairing);
    	element_pow_zn(gbs->PK->g_iiii[0],gbs->PK->g,t19);
    	//element_printf("g_iiii[1025] = %B\n", gbs->PK->g_iiii[0]);
    	
    	for(int i = 1; i <MAX_N; i++)
    	{	int jj;
    		jj=MAX_N+1+i;
    		element_init_Zr(t20, gps->pairing);
    		element_set_si(t20,jj);
        	element_t temp1,temp2,temp3,temp4;
        	element_init_G1(gbs->PK->g_i[i], gps->pairing);
        	element_pow_zn(gbs->PK->g_i[i], gbs->PK->g_i[i-1], alpha);//  g ^ alpha^i = (g^(alpha^i))
        	//element_printf("g^(alpha)^(%d) = %B\n\n", i, gbs->PK->g_i[i]);
        	element_init_G1(gbs->PK->g_ii[i], gps->pairing);
        	element_pow_zn(gbs->PK->g_ii[i], gbs->PK->g_ii[i-1], alpha);//g^ alpha^(i+1) = (g^(alpha^(i+1)))
        	//element_printf("g^(alpha)^(%d+1) = %B\n\n", i, gbs->PK->g_ii[i]);
        	element_init_G1(gbs->PK->g_iii[i], gps->pairing);
        	element_init_Zr(temp1,gps->pairing);
        	element_init_Zr(temp2,gps->pairing);
        	element_init_Zr(temp3,gps->pairing);
        	element_init_Zr(temp4,gps->pairing);
        	element_set_si(temp2,i);
        	element_sub(temp1,t19,temp2);
        	element_pow_zn(temp3,alpha,temp1);
        	element_pow_zn(gbs->PK->g_iii[i], gbs->PK->g, temp3);//  g_i ^ alpha^(v+1-i) = (g^(alpha^i))^alpha
        	//element_printf(".......g^(alpha)^(%B) = %B\n\n", temp1, gbs->PK->g_iii[i]);
        	element_pow_zn(temp4,alpha,t20);
        	element_init_G1(gbs->PK->g_iiii[i], gps->pairing);
        	element_pow_zn(gbs->PK->g_iiii[i], gbs->PK->g, temp4);//  g_i ^ alpha^(v+1+i) = (g^(alpha^i))^alpha
        	//element_printf(".......g^(alpha)^(%B) = %B\n\n", t20, gbs->PK->g_iiii[i]);
        	
    	}
    	
//------------------------ Compute the private keys SK_j_i -----------------------------------------------------
	
	for(int i = 0; i <MAX_N; i++)
    	{
    		int ii1,ii2;
    		element_t tt1,tt2,tt3;
    		element_init_G1(gbs->d[i][0], gps->pairing);
            	element_pow_zn(gbs->d[i][0],gbs->PK->g_i[i], gamma);
            	//element_printf("The first component of secret key SKey[%d][0] is %B\n",i, gbs->d[i][0]);
            	element_init_Zr(tt1, gps->pairing);
            	ii1=i/MAX_n;
            	//printf("m=%d\n\n",ii1);
            	element_mul(tt1,gbs->PK->beta[ii1],gamma);
            	element_init_G1(gbs->d[i][1], gps->pairing);
            	element_pow_zn(gbs->d[i][1],gbs->PK->g, tt1);
            	//element_printf("The value of  beta[%d] = %B\n", ii1, gbs->PK->beta[ii1]);
            	//element_printf("The second component of secret key SKey[%d][1] is %B\n",i, gbs->d[i][1]);
    	}
	
	
	
	*sys = gbs; 
 }
//----------------------------Key Gen is done -----------------------------------------------------------------


//===================================== Encryption =====================================================

void get_enc_key(header_t hdr,  bkem_system_t gbs, bkem_global_params_t gps) 
{	
        
        element_t s,t11,t12,t13,t14,t15,t16,t17,t18,t19,r1;
        int z1,z2,z3;
	element_init_Zr(s, gps->pairing);
	element_random(s);
//-------------------------------------1st ciphertext component (ct_1) --------------------------------
  	element_init_G1(t11, gps->pairing);
  	element_set1(t11);
 	for(int j=0;j<num_recip;++j)
 	{
 		element_mul(t11,t11,gbs->PK->g_iii[j]);
 		
 	}
        element_init_G1(t12, gps->pairing);
        element_mul(t12,t11,gbs->PK->v);
        element_init_G1(gbs->ct_1, gps->pairing);
        element_pow_zn(gbs->ct_1,t12,s);
        //element_printf("The 1st ciphertext component %B\n",gbs->ct_1); 
       
//-------------------------------------2nd ciphertext component (ct_2) --------------------------------
        element_init_G1(gbs->ct_2, gps->pairing);
        element_pow_zn(gbs->ct_2,gbs->PK->g,s);
        //element_printf("The 2nd ciphertext component %B\n",gbs->ct_2); 	
        
//-------------------------------------compute group key for each channel ---------------------------------------------
	
	for (int j = 0; j < 4; ++j) 
	 {	
	 	element_init_G1(t13, gps->pairing);
	 	element_pow_zn(t13,gbs->PK->g,gbs->PK->beta[j]);
	    	element_init_G1(t14, gps->pairing);
	    	element_pow_zn(t14,gbs->PK->v,s);
	    	element_init_GT(t16, gps->pairing);
	    	pairing_apply(t16, t13, t14, gps->pairing);
	    	//--------------------------------------------------------
	    	element_init_G1(t18, gps->pairing);
	    	element_pow_zn(t18,gbs->PK->g_ii[0],s);
	    	element_init_GT(t19, gps->pairing);
	    	pairing_apply(t19, gbs->PK->g_ii[MAX_N-1], t18, gps->pairing);
	    	element_init_GT(gbs->Gkey[j], gps->pairing);
	    	element_mul(gbs->Gkey[j],t19,t16);
	    	//element_printf("The group key for $%d$-th channel %B\n",j,gbs->Gkey[j]);
		    	  					
    	}
	
}

//========================================= Decryption ==============================================

void get_decryption_key(bkem_global_params_t gps, bkem_system_t gbs, pubkey_t PK)
 {
 	int ch=1;// 0th channel
 	int usr=5;// 5th user of 0th channel
 		
 //--------------------------------------------------------------------------------------------------
   	int tt;
   	element_t t21,t22,t23,t24,t25,t26,t27,t28,t29,t31,t32;
   	element_init_G1(t22, gps->pairing);
	element_set1(t22);
 	element_init_GT(t21, gps->pairing);
 	tt=ch*MAX_n+usr;
 	pairing_apply(t21, gbs->PK->g_i[tt],gbs->ct_1, gps->pairing);
 	for (int jj = 0; jj < num_recip; ++jj) 
	 {	
	 	
	 	int d1;
	 	d1=MAX_N+1-jj+tt;
	 	element_init_Zr(t31, gps->pairing);
	 	element_set_si(t31,d1);
	 	element_init_G1(t32, gps->pairing);
	 	element_pow_zn(t32,gbs->PK->g_ii[0],t31);
	 	element_mul(t22,t22,t32);
	  }
	//element_printf("The product is %B\n\n",t22);
 	element_init_G1(t23, gps->pairing);
 	element_div(t23,t22, gbs->PK->g_iii[0]);
 	element_init_G1(t24, gps->pairing);
 	element_mul(t24,t23, gbs->d[tt][0]);
 	element_init_GT(t25, gps->pairing);
 	pairing_apply(t25, t24, gbs->ct_2, gps->pairing);//denominator 
 	element_init_GT(t26, gps->pairing);
 	element_div(t26, t21, t25);
 	element_init_GT(t28, gps->pairing);
 	pairing_apply(t28, gbs->d[tt][1], gbs->ct_2, gps->pairing);
 	element_init_GT(t29, gps->pairing);
 	element_mul(t29, t28, t26);
 	//element_printf("The recovered group key for %d th channel %B\n\n", ch, t29);
 	
}


void free_global_params(bkem_global_params_t gbs) {
    if (!gbs)
        return;

    pairing_clear(gbs->pairing);
    free(gbs);
}

void free_pubkey(pubkey_t pk, bkem_global_params_t gbs) {
    if (!pk)
        return;

    element_clear(pk->g);

    int i;
    for (i = 0; i <= gbs->N; ++i) {
        element_clear(pk->g_i[i]);
    }

    //for (i = 0; i < gbs->A; ++i) {
       // element_clear(pk->v_i[0]);
    //}

}

void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs) {
    if (!sys)
        return;

    free_pubkey(sys->PK, gbs);

    int i;
    /*for (i = 0; i < gbs->N; ++i) {
        element_clear(sys->d_i[i]);
    }*/
}
