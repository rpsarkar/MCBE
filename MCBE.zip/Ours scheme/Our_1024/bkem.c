 
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gmp.h>
#include "bkem.h"
#include <time.h>
//clock_t t,t1,t0,t2,t4;
void setup_global_system(bkem_global_params_t *gps, const char *pstr, int N) {
    
    bkem_global_params_t params;
    params = pbc_malloc(sizeof(struct bkem_global_params_s));

    params->N = N;
    
    pairing_init_set_str(params->pairing, pstr);

    *gps = params;
}

int sizeOf(ID ij)
{
    return (int)(2*sizeof(int));
}

void hashID(element_t hash, ID IDij, bkem_global_params_t gps)
{	
    element_init_Zr(hash, gps->pairing);
    element_from_hash(hash, &IDij, sizeOf(IDij));
}


void setup(bkem_system_t *sys, bkem_global_params_t gps) 
{
    //t0 = clock();
    
    // 
    bkem_system_t gbs;
    bkem_secret_key_t sk;
    gbs = pbc_malloc(sizeof(struct bkem_system_s));
    gbs->PK = pbc_malloc(sizeof(struct pubkey_s));

    // ---------------------------------Choose random generator g --------------------------------------------
    element_init_G1(gbs->PK->g, gps->pairing);
    element_random(gbs->PK->g);

    //----------------------------------Choose another generator ghat=gg--------------------------------------
    element_init_G2(gbs->PK->gg, gps->pairing);
    element_random(gbs->PK->gg);

    // ---------------------------------random alpha in Zn ---------------------------------------------------
    element_t alpha;
    element_init_Zr(alpha, gps->pairing);
    element_random(alpha);

    // ---------------------------------random beta in Zn-----------------------------------------------------
    element_t beta1;
    element_init_Zr(beta1, gps->pairing);
    element_random(beta1);

    // ---------------------------------random xhat in Zn ----------------------------------------------------
    element_t xhat;
    element_init_Zr(xhat, gps->pairing);
    element_random(xhat);

    // ---------------------------------random yhat in Zn ----------------------------------------------------
    element_t yhat;
    element_init_Zr(yhat, gps->pairing);
    element_random(yhat);

    /*
    element_printf("alpha = %B\n", alpha);
    element_printf("beta1 = %B\n", beta1);
    element_printf("xhat = %B\n", xhat);
    element_printf("yhat = %B\n\n", yhat);
    */	

   // -------------------------------Compute the component of MPK ---------------------------------------------
    gbs->PK->g_i = pbc_malloc( 7 * sizeof(element_t));
    int size_of_MPK=6 * sizeof(element_t);
    element_printf("size_of_MPK = %d in bytes\n\n", size_of_MPK);
   
    
   // element_printf("Compute the component of MPK\n");
	
     //-----------------------------Set the first element to g--------------------------------------------------
    element_init_G1(gbs->PK->g_i[0], gps->pairing);
    element_set(gbs->PK->g_i[0],gbs->PK->g);
    //element_printf("g = %B\n\n", gbs->PK->g_i[0]);
    
    //-------------------------------Set the first element to ghat---------------------------------------------
    element_init_G2(gbs->PK->g_i[1], gps->pairing);
    element_set(gbs->PK->g_i[1],gbs->PK->gg);
    //element_printf("ghat = %B\n\n", gbs->PK->g_i[1]);
   
    
    //-------------------------------Set the first element to ghat_1=(ghat)^alpha--------------------------------
    element_init_G2(gbs->PK->g_i[2], gps->pairing);
    element_pow_zn(gbs->PK->g_i[2], gbs->PK->gg, alpha);
    //element_printf("ghat_1 = %B\n\n", gbs->PK->g_i[2]);
    
    //------------------------------Set the first element to g_2=(g)^beta----------------------------------------
    element_init_G1(gbs->PK->g_i[3], gps->pairing);
    element_pow_zn(gbs->PK->g_i[3], gbs->PK->g, beta1);
    //element_printf("g_2 = %B\n\n", gbs->PK->g_i[3]);
    
    //-------------------------------Set the first element to Xhat=(ghat)^xhat-------------------------------------
    element_init_G2(gbs->PK->g_i[4], gps->pairing);
    element_pow_zn(gbs->PK->g_i[4], gbs->PK->gg, xhat);
    //element_printf("Xhat = %B\n\n", gbs->PK->g_i[4]);
    
    //------------------------------Set the first element to Yhat=(ghat)^yhat----------------------------------------
    element_init_G2(gbs->PK->g_i[5], gps->pairing);
    element_pow_zn(gbs->PK->g_i[5], gbs->PK->gg, yhat);
    //element_printf("Yhat = %B\n\n", gbs->PK->g_i[5]);
    

    //element_printf("Compute the component of MSK\n");
    
    //-------------------------------Set the first element to ghat_2=(ghat)^beta--------------------------------------
    element_init_G2(gbs->PK->g_i[6], gps->pairing);
    element_pow_zn(gbs->PK->g_i[6], gbs->PK->gg, beta1);
    //element_printf("ghat_2 = %B\n\n", gbs->PK->g_i[6]);
    
    //t0 = clock() - t0;
    //double time_taken0 = ((double)t0)/CLOCKS_PER_SEC; // in seconds 
    //printf("Setup took %f seconds to execute \n\n", time_taken0);  
    
     
    //int size_of_MSK=3 * sizeof(element_t);
    //element_printf("size_of_MSK = %d in bytes\n\n", size_of_MSK);
   
   //------------------MPK and MSK generation is done ----------------------------------------------------------------
    
   int i,j;
   element_t d, d1,e1;

    // -----------To Compute private keys store the hash values--------------------------------------------------------
    
    //t0 = clock();
    element_init_Zr(gbs->all_hash_sum, gps->pairing);
    element_set0(gbs->all_hash_sum);
    //element_init_Zr(gbs->check, gps->pairing);
    //element_set0(gbs->check);
    for (int j = 0; j < MAX_m; ++j) {
	element_init_Zr(gbs->channel_hash_sum[j], gps->pairing);
    	element_set0(gbs->channel_hash_sum[j]);
        for (int i = 0; i < MAX_n; ++i) 
        {
	    element_init_Zr(gbs->hash_store[j][i],gps->pairing);
	    element_random(gbs->hash_store[j][i]);
            //element_printf("hash_store[%d][%d] = %B\n\n", j,i, gbs->hash_store[j][i]);
            element_add(gbs->channel_hash_sum[j], gbs->hash_store[j][i], gbs->channel_hash_sum[j]);
            element_add(gbs->all_hash_sum, gbs->hash_store[j][i], gbs->all_hash_sum);
         }
         //element_printf("Sum of hash values of the channel %d = %B\n\n", j, gbs->channel_hash_sum[j]);
         //element_add(gbs->check, gbs->channel_hash_sum[j], gbs->check);
    }
    //element_printf("Sum of all hash values of the system = %B\n\n", gbs->all_hash_sum);
    //element_printf("Sum of all hash values of the system = %B\n\n", gbs->check);
    

   
    
   //------------------------ Compute the private keys SK_j_i -----------------------------------------------------
   
    for (int j = 0; j < MAX_m; ++j) {
        for (int i = 0; i < MAX_n; ++i)
         {
            element_init_G2(gbs->d[j][i][0], gps->pairing);
            element_pow_zn(gbs->d[j][i][0],gbs->PK->g_i[6], gbs->hash_store[j][i]);
            //element_printf("Secret Key [%d][%d][0] = %B\n\n", j,i, gbs->d[j][i][0]);
            element_init_G2(gbs->d[j][i][1], gps->pairing);
            element_init_Zr(d, gps->pairing);
            element_sub(d, gbs->channel_hash_sum[j], gbs->hash_store[j][i]);
            element_pow_zn(gbs->d[j][i][1],gbs->PK->g_i[6], d);
            //element_printf("Secret Key [%d][%d][1] = %B\n\n", j,i, gbs->d[j][i][1]);
            element_init_G2(gbs->d[j][i][2], gps->pairing);
            element_init_Zr(d1, gps->pairing);
            element_sub(d1, gbs->all_hash_sum, gbs->hash_store[j][i]);
            element_pow_zn(gbs->d[j][i][2],gbs->PK->g_i[6], d1);
            //element_printf("Secret Key [%d][%d][2] = %B\n\n", j,i, gbs->d[j][i][2]);
            
        }
    }
 
 	//t0 = clock() - t0;
    	//double time_taken1 = ((double)t0)/CLOCKS_PER_SEC; // in seconds 
    	//printf("KeyGen took %f seconds to execute \n\n", time_taken1);  
    	
    	
       *sys = gbs;
    	element_clear(alpha);
    	element_clear(beta1);
	element_clear(xhat);
	element_clear(yhat);
	int size_of_users_secret_key=3 * sizeof(element_t);
    	element_printf("size_of_users_secret_key = %d in bytes\n\n", size_of_users_secret_key);
   
 }
//----------------------------Key Gen is done -----------------------------------------------------------------


//----------------------------------------Encryption ---------------------------------------------------------

void get_enc_key(header_t hdr,  bkem_system_t gbs, bkem_global_params_t gps) 
{	
        
        element_t s,t1,t2,t3,t4,t5,t6,t7,r1;
	element_init_Zr(s, gps->pairing);
	element_random(s);
	for (int j = 0; j < 4; ++j) 
	 {
	 	//-------------------------------------1st ciphertext component (C_1_x) --------------------------------
	    	element_init_G2(t1, gps->pairing);
    		element_div(t1,gbs->PK->g_i[1],gbs->PK->g_i[2]);
    		element_init_Zr(t2, gps->pairing);
       	element_sub(t2,gbs->all_hash_sum,gbs->channel_hash_sum[j]);
       	element_init_G2(t3, gps->pairing);
       	element_pow_zn(t3,t1,t2);
       	element_init_G2(t4, gps->pairing);
       	element_pow_zn(t4,t3,s);
		element_init_GT(gbs->C_1_x[j], gps->pairing);
		pairing_apply(gbs->C_1_x[j], gbs->PK->g_i[3], t3, gps->pairing); // r1 = e(g_2, (g_1/g)^(\sum ....))^s
		//element_printf("C_1_x[%d]= %B\n\n", j,gbs->C_1_x[j]);
/*		
		//-------------------------------------store all messages M_x in a array --------------------------------
      		element_init_GT(gbs->M_x[j], gps->pairing);
      		element_random(gbs->M_x[j]);
      		//element_printf("M_x[%d]= %B\n\n", j,gbs->M_x[j]);
*/      		
      		//-------------------------------------2nd ciphertext component (C_2_x) --------------------------------
       	element_init_G2(t5, gps->pairing);
       	element_pow_zn(t5,gbs->PK->g_i[2],t2);
       	element_init_G2(t6, gps->pairing);
       	element_pow_zn(t6,t5,s);
		element_init_GT(gbs->C_22_x[j], gps->pairing);
		element_init_GT(gbs->C_2_x[j], gps->pairing);
		pairing_apply(gbs->C_22_x[j], gbs->PK->g_i[3], t6, gps->pairing); 
		//element_mul(gbs->C_2_x[j],gbs->M_x[j], gbs->C_22_x[j]);
		//element_printf("C_2_x[%d]= %B\n\n", j,gbs->C_2_x[j]);
			
    	}
   	
	//-------------------------------------3rd ciphertext component (C_0) --------------------------------
       element_init_G1(gbs->C_0, gps->pairing);
       element_pow_zn(gbs->C_0,gbs->PK->g_i[0],s);
       //element_printf("C_0= %B\n\n", gbs->C_0);
       element_clear(s);
          	
}


void get_decryption_key(bkem_global_params_t gps, bkem_system_t gbs, pubkey_t PK)
 {
 	int j=0;
 	int i=1;
 		
 //--------------- For DEM Mechanism -----------------------------------------------------------------
/*   	element_t t1,t2,t3,t4,t5,t6,Guess_M_x;
 	element_init_G2(t1, gps->pairing);
 	element_mul(t1,gbs->d[j][i][0], gbs->d[j][i][1]);
 	element_init_G2(t2, gps->pairing); 	
 	element_mul(t2,gbs->d[j][i][0], gbs->d[j][i][2]);
 	element_init_GT(t3, gps->pairing);
     	pairing_apply(t3, gbs->C_0, t1, gps->pairing);
     	element_init_GT(t4, gps->pairing);
     	pairing_apply(t4, gbs->C_0, t2, gps->pairing);
     	element_init_GT(t5, gps->pairing);
     	element_div(t5, t4, t3);  
     	element_init_GT(t6, gps->pairing);
     	element_div(t6, gbs->C_2_x[j], gbs->C_1_x[j]); 
     	element_init_GT(Guess_M_x, gps->pairing); 	
 	element_mul(Guess_M_x,t5, t6); 
 	//element_printf("The plaintext is %B\n\n",gbs->M_x[j]);
 	//element_printf("The recover message is %B\n\n",Guess_M_x);
*/ 
 
 //----------------- For KEM Mechanism----------------------------------------------------------------
 
 	element_t td1,td2,td3,td4,td5,td6,Guess_M_x;
 	element_init_G2(td1, gps->pairing);
 	element_mul(td1,gbs->d[j][i][0], gbs->d[j][i][1]);
 	element_init_G2(td2, gps->pairing); 	
 	element_mul(td2,gbs->d[j][i][0], gbs->d[j][i][2]);
 	element_init_GT(td3, gps->pairing);
     	pairing_apply(td3, gbs->C_0, td1, gps->pairing);
     	element_init_GT(td4, gps->pairing);
     	pairing_apply(td4, gbs->C_0, td2, gps->pairing);
     	element_init_GT(td5, gps->pairing);
     	element_div(td5, td4, td3);  
 	//element_printf("The Group-key is %B\n\n",td5);
	
 	
}


void free_global_params(bkem_global_params_t gbs) {
    if (!gbs)
        return;

    pairing_clear(gbs->pairing);
    free(gbs);
}

void free_pubkey(pubkey_t pk, bkem_global_params_t gbs) {
    if (!pk)
        return;

    element_clear(pk->g);

    int i;
    for (i = 0; i <= gbs->N; ++i) {
        element_clear(pk->g_i[i]);
    }

    //for (i = 0; i < gbs->A; ++i) {
       // element_clear(pk->v_i[0]);
    //}

}

void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs) {
    if (!sys)
        return;

    free_pubkey(sys->PK, gbs);

    int i;
    /*for (i = 0; i < gbs->N; ++i) {
        element_clear(sys->d_i[i]);
    }*/
}
